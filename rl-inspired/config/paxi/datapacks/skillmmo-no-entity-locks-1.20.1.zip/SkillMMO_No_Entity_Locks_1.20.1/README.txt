SkillMMO - No Entity Locks (1.20.x)
Drop this zip into a world's datapacks folder and enable it.
It filters out all 'skillmmo:tags/entity_types/skills/**' so entities are never gated by skills.
Item/block locks remain unchanged.
